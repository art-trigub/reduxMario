<?php

declare(strict_types=1);

namespace App\Repositories\Contracts;

use App\Entities\Authitem;

interface AuthItemRepository
{
    public function getById(int $id): Authitem;

}
