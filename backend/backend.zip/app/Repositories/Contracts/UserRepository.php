<?php

declare(strict_types=1);

namespace App\Repositories\Contracts;

use App\Entities\User;

interface UserRepository
{
    public function getById(int $id);

    public function getAll():array;

    public function save(User $user): User;

    public function getByLogin(string $login): ?User;

}
