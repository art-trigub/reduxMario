<?php

declare(strict_types=1);

namespace App\Repositories;

use App\Entities\Department;
use App\Repositories\Contracts\DepartmentRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\ORM\EntityManagerInterface;
use Doctrine\ORM\EntityRepository;
use Doctrine\ORM\Mapping;

final class DoctrineDepartmentRepository extends EntityRepository implements DepartmentRepository
{

    public function getById(int $id): Department
    {
        $this->find($id);
    }

    public function getAll(): ArrayCollection
    {
        $this->getAll();
    }

    public function save(Department $department): Department
    {
        $this->save($department);
    }

}
