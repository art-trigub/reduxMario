<?php

declare(strict_types=1);

namespace App\Repositories;

use App\Entities\User;
use App\Entities\Userphone;
use App\Repositories\Contracts\UserPhoneRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\ORM\EntityRepository;

final class DoctrineUserPhoneRepository extends EntityRepository implements UserPhoneRepository
{
    public function getById(int $id): Userphone
    {
        $this->createQueryBuilder('up')
            ->andWhere('up.id = :id')
            ->setParameter('id', $id)
            ->getQuery()
            ->getOneOrNullResult();
    }

    public function getAll(): ArrayCollection
    {
        $this->getAll();
    }

    public function save(Userphone $userphone): Userphone
    {
        $this->save($userphone);
    }



}
