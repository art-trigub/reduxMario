<?php

declare(strict_types=1);

namespace App\Repositories;

use App\Entities\Role;
use App\Repositories\Contracts\RoleRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\ORM\EntityRepository;

final class DoctrineRoleRepository extends EntityRepository implements RoleRepository
{
    public function getById(int $id): Role
    {
        $this->find($id);
    }

    public function getAll(): ArrayCollection
    {
        $this->getAll();
    }

    public function save(Role $role): Role
    {
        $this->save($role);
    }
}
