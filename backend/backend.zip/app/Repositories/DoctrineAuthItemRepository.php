<?php

declare(strict_types=1);

namespace App\Repositories;

use App\Entities\Authitem;
use App\Repositories\Contracts\AuthItemRepository;
use Doctrine\ORM\EntityRepository;

final class DoctrineAuthItemRepository extends EntityRepository implements AuthItemRepository
{
    public function getById(int $id): Authitem
    {
        $this->find($id);
    }

}
