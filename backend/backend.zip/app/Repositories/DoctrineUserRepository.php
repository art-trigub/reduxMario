<?php

declare(strict_types=1);

namespace App\Repositories;

use App\Entities\User;
use App\Repositories\Contracts\UserRepository;
use Doctrine\ORM\EntityRepository;


final class DoctrineUserRepository extends EntityRepository implements UserRepository
{
    public function getById(int $id)
    {
        return $this->find($id);
    }

    public function getAll(): array
    {
        return $this->findAll();
    }

    public function save(User $user): User
    {
        $this->save($user);
    }

    public function getByLogin(string $login): ?User
    {
        $this->createQueryBuilder('u')
            ->andWhere('u.login = :login')
            ->setParameter('login', $login)
            ->getQuery()
            ->getOneOrNullResult();
    }

}
