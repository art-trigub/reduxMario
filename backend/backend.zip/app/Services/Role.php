<?php
declare(strict_types=1);
namespace App\Services;

class Role extends Item
{

    public $type = self::TYPE_ROLE;

}
