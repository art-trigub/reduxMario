<?php

declare(strict_types=1);

namespace App\Http\Controllers\Api;

use App\Actions\User\GetUserByIdAction;
use App\Actions\User\GetUsersAction;
use App\Http\Resources\GetUsersResource;
use App\Http\Resources\UserResource;
use App\Http\Response\ApiResponse;
use App\Http\Controllers\Controller;

final class UserController extends Controller
{
    private $getUsersAction;
    private $getUserByIdAction;

    public function __construct(
        GetUsersAction $getUsersAction,
        GetUserByIdAction $getUserByIdAction
    )
    {
        $this->getUsersAction = $getUsersAction;
        $this->getUserByIdAction = $getUserByIdAction;
    }

    public function getUsers():ApiResponse
    {
        $response =  $this->getUsersAction->execute();
        return  ApiResponse::success(new GetUsersResource($response->users()));
    }

    public function getUserById(int $id): ApiResponse
    {
        $response = $this->getUserByIdAction->execute($id);
        return  ApiResponse::success(new UserResource($response->getUser()));
    }

}
