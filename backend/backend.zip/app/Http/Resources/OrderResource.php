<?php

declare(strict_types=1);

namespace App\Http\Resources;

use App\Contracts\ApiResponse;
use Illuminate\Http\Resources\Json\JsonResource;

final class OrderResource extends JsonResource implements ApiResponse
{
    public function toArray($request): array
    {
        return [
            'client_id' => $this->client_id,
            'user_id' => $this->user_id,
            'id' => $this->id,
            'date_start' => $this->date_start,
            'services' => $this->orderServices()->get(),
            'client' => $this->client()->get(),
        ];
    }
}
