<?php

declare(strict_types=1);

namespace App\Http\Resources\Traits;

use App\Entities\Department;
use App\Entities\Role;
use App\Entities\Userphone;

trait PresentUserTrait
{
    public function presentUser($item): array
    {
        return [
            'id' => $item->getId(),
            'firstName' => $item->getFirstName(),
            'lastName' => $item->getLastName(),
            'photo' => $item->getPhoto(),
            'login' => $item->getLogin(),
            'phoneNumber' => $item->getPhoneNumber(),
            'role' => $this->presentRole($item->getRole()),
            'dateOfBirth' => $item->getDateOfBirth(),
            'dateStart' => $item->getDateStart(),
            'dateFired' => $item->getDateFired(),
            'phones' => $this->presentCollection($item->getPhones()),
            'permissions' => $item->getPermissions(),
        ];
    }


    public function presentDepartment(?Department $department): array
    {
        if(!empty($department)) {
            return [
                'id' => $department->getId(),
                'name' => $department->getName()
            ];
        }
        return [];
    }

    public function presentRole(?Role $role): array
    {
        if(!empty($role)) {
            return [
                'id' => $role->getId(),
                'name' => $role->getName(),
                'department' => $role->getDepartment()->getName()
            ];
        }
        return [];
    }


    public function present(Userphone $userphone): array
    {
        return [
            'id' => $userphone->getId(),
            'phoneInternal' => $userphone->getPhoneInternal(),
            'phoneExternal' => $userphone->getPhoneExternal()
        ];
    }

    public function presentCollection(\Doctrine\Common\Collections\Collection $collection): array
    {
        return $collection
            ->map(function (Userphone $userphone) {
                return $this->present($userphone);
            })
            ->toArray();
    }

}
