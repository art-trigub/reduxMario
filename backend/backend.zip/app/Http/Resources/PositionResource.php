<?php

declare(strict_types=1);

namespace App\Http\Resources;

use App\Contracts\ApiResponse;
use Illuminate\Http\Resources\Json\JsonResource;

final class PositionResource extends JsonResource implements ApiResponse
{
    public function toArray($request): array
    {
        return [
            'name' => $this->name,
            'p_id' => $this->p_id,
            'id' => $this->id,
            'is_active' => $this->is_active
        ];
    }
}
