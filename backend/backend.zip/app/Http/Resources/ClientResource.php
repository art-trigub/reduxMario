<?php

declare(strict_types=1);

namespace App\Http\Resources;

use App\Contracts\ApiResponse;
use Illuminate\Http\Resources\Json\JsonResource;

final class ClientResource extends JsonResource implements ApiResponse
{
    public function toArray($request): array
    {
        return [
            'firstName' => $this->first_name,
            'lastName' => $this->last_name,
            'birthDay' => $this->birth_date,
            'gender' => $this->gender,
            'address' => $this->address,
            'img_avatar' => $this->img_avatar,
            'contacts' => $this->contacts,
        ];
    }
}
