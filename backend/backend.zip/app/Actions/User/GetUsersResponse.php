<?php

declare(strict_types=1);

namespace App\Actions\User;

use Illuminate\Support\Collection;


class GetUsersResponse
{
    private $users;

    public function __construct(Collection $users)
    {
        $this->users = $users;
    }

    public function users(): Collection
    {
        return $this->users;
    }
}
