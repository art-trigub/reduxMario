<?php

declare(strict_types=1);
namespace App\Actions\User;

use App\Repositories\Contracts\UserRepository;

class GetUsersAction
{
    private $userRepository;

    public function __construct(UserRepository $userRepository)
    {
        $this->userRepository = $userRepository;
    }

    public function execute(): GetUsersResponse
    {

        return new GetUsersResponse(collect($this->userRepository->getAll()));
    }
}
