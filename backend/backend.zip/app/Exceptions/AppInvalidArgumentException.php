<?php


namespace App\Exceptions;

class AppInvalidArgumentException extends AppException
{
}
