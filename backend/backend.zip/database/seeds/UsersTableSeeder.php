<?php

use App\Entities\User;
use Illuminate\Database\Seeder;
use LaravelDoctrine\ORM\Facades\EntityManager;
use \LaravelDoctrine\ORM\Testing;

class UsersTableSeeder extends Seeder
{

    private $entityManager;
    private $faker;

    public function __construct(\Doctrine\ORM\EntityManager $entityManager, Faker\Generator $faker)
    {
        $this->entityManager = $entityManager;
        $this->faker = $faker;
    }
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $faker = $this->faker;
        $con = $this->entityManager->getConnection();

        $con->insert('users',
        [
            'first_name' => $faker->firstName,
            'last_name' => $faker->firstName,
            'email' => $faker->unique()->safeEmail,
            'phone_number' => $faker->unique()->phoneNumber,
            'role_id' =>  EntityManager::createQueryBuilder()->select('t')
                ->from(\App\Entities\Role::CLASS, 't')
                ->setMaxResults(1)->getQuery()->getSingleResult()->getId(),
            'login' =>'m.tarantsova',
            'date_of_birth' => date('Y-m-d'),
            'date_start' => date('Y-m-d H:i:s'),
            'created_at' => date('Y-m-d H:i:s'),
            'password' => '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', // password
        ]);
    }
}
