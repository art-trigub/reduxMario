<?php


use Illuminate\Support\Facades\Route;

Route::prefix('v1')->group(function () {
    Route::group([
        'prefix' => 'auth',
        'namespace' => 'Api\\Auth'
    ], function () {
        Route::post('/login', 'AuthController@login');
        Route::get('/me', 'AuthController@getCurrentUser')->middleware('auth:api');
    });


    Route::group([
        'namespace' => 'Api',
        'middleware' => 'auth:api'
    ], function () {
        Route::group([
            'prefix' => 'users'
        ], function () {
            Route::get('/all', 'UserController@getUsers');
            Route::get('/get/{id}', 'UserController@getUserById');
        });

    });

});




