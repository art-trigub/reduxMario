<?php
namespace Tests\Feature;

use Tests\TestCase;
use Tymon\JWTAuth\Facades\JWTAuth;

class UserAuthTest extends TestCase
{

    private $em;
    private $user;

    protected function setUp(): void
    {
        parent::setUp();
        $this->em = app('em');
        $this->em->getConnection()->beginTransaction();

       $this->user = entity(\App\Entities\User::class)->create([
            'login' => 'u.tarantsovak',
            'email' => 'yashuk777@gmail.com',
            'password' => bcrypt('password')
        ]);
    }

    public function testSuccessLogin()
    {

        $response = $this->json('POST', 'api/v1/auth/login', [
            'login' => 'u.tarantsovak',
            'password' => 'password',
        ]);

        $response->assertStatus(200);
        $response->assertJsonStructure([
            'data' => [
                'token'
            ]
        ]);
    }

    public function testFailLogin()
    {
        $response = $this->json('POST', 'api/v1/auth/login', [
            'login' => 'test@gmail.com11',
            'password' => 'secret1234',
        ]);

        $response->assertStatus(400);

        $this->assertEquals('User doesn\'t exist', $response->json('error.message'));
        $response->assertJsonStructure([
            'error'
        ]);
    }

    public function testCurrentUser()
    {

        $token = JWTAuth::fromUser( $this->user);
        $headers = ['Authorization' => "Bearer $token"];
        $response = $this->json('GET', 'api/v1/auth/me',[], $headers);
        $this->assertEquals(200, $response->getStatusCode());
    }

    public function testGetUser()
    {
        $token = JWTAuth::fromUser($this->user);
        $headers = ['Authorization' => "Bearer $token"];
        $response = $this->json('GET', 'api/v1/users/all',[], $headers);
        $response->assertStatus(200);
    }

    public function testGetUserById()
    {
        $token = JWTAuth::fromUser($this->user);
        $headers = ['Authorization' => "Bearer $token"];

        $response = $this->json('GET', 'api/v1/users/get/' . $this->user->getId(),[], $headers);
        $response->assertStatus(200);
    }

    public function tearDown(): void
    {
        parent::tearDown();

        $this->em->getConnection()->rollback();

    }
}
